import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Component/Login';
import Info from './Component/Info';
import Home from './Component/Home';
import Welcome from './Component/Welcome';
import Register from './Component/Register';
import Salary from './Component/Salary';
import DocumentCenter from './Component/DocumentCenter';
import Settings from './Component/Settings';
import Help from './Component/Help';
import Chatbot from './Component/Chatbot.js';

import PFCalculator from './Component/PFCalculator.js';
import About from './Component/About';
import React, { useEffect } from 'react';
import ViewEmployee from './HrComponent/ViewEmployee.js';
import EmployeeAdd from './HrComponent/EmployeeAdd.js';
import Hrhome from './HrComponent/Hrhome.js';
import HrInfo from './HrComponent/HrInfo.js';
import HrSalary from './HrComponent/HrSalary.js';
import HrDocumentCenter from './HrComponent/HrDocumentCenter.js';
import HrSettings from './HrComponent/HrSettings.js';
import HrHelp from './HrComponent/HrHelp.js';

function App() {
  useEffect(function () {
    function disableBackButton(e) {
      // Prevent going back in history
      window.history.forward();
    }

    // Attach the event listener when the component mounts
    window.addEventListener('popstate', disableBackButton);

    // Clean up the event listener when the component unmounts
    return function () {
      window.removeEventListener('popstate', disableBackButton);
    };
  }, []); // Empty
  return (
    <>
      <Routes>

        <Route path='/' element={<Welcome />} />
        <Route path='Register' element={<Register />} />
        <Route path='/home' element={<Home />} />
        <Route path='/info' element={<Info />} />
        <Route path='/login' element={<Login />} />
        <Route path='/salary' element={<Salary />} />
        <Route path='/documentcenter' element={<DocumentCenter />} />
        <Route path='/settings' element={<Settings />} />
        <Route path='/help' element={<Help />} />
        <Route path='/calculator' element={<PFCalculator />} />
        <Route path='/About' element={<About />} />
        <Route path='/viewemployee' element={<ViewEmployee />} />
        <Route path='/addemployee' element={<EmployeeAdd />} />
        <Route path='/hrhome' element={<Hrhome />} />
        <Route path='/hrinfo' element={<HrInfo />} />
        <Route path='/hrsalary' element={<HrSalary />} />
        <Route path='/hrdocumentcenter' element={<HrDocumentCenter/>} />
        <Route path='/hrsettings' element={<HrSettings />} />
        <Route path='/hrhelp' element={<HrHelp />} />

      </Routes>
    </>

  );
}

export default App;