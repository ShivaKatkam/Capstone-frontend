import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import HomeNavbar from "./HomeNavbar";
import SideBar from "./SideBar";
import "./Info.css"
function Info() {
    const [selectedOption, setSelectedOption] = useState('Personal');
    const [profileInfo, setProfileInfo] = useState({
        Name: '',
        EmployeeID: '',
        CompanyEmail: '',
        Location: '',
    });
    const [personalInfo, setPersonalInfo] = useState({
        BloodGroup: '',
        DateofBirth: '',
        PhysicallyChallenged: '',
        Nationality: '',
    });
    const [addressInfo, setAddressInfo] = useState({
        Address: '',
        Name: '',
        Email: '',
        Mobile: '',
    });
    const [addressType, setAddressType] = useState('Contact Address');
 
    function handleOptionChange(option) {
        setSelectedOption(option);
    }
 
    return (
        <div className="flex flex-col h-screen" >
 
            <div><HomeNavbar /></div>
            <div className='flex flex-1'>
 
                <SideBar />
                <div class="flex-1 p-8">
                    <h1>Employee Information</h1>
 
                    <div className="options">
                        <button onClick={function () { handleOptionChange('profile'); }} className={selectedOption === 'profile' ? 'active' : ''}>
                            Profile
                        </button>
                        <button onClick={function () { handleOptionChange('personal'); }} className={selectedOption === 'personal' ? 'active' : ''}>
                            Personal
                        </button>
                        <button onClick={function () { handleOptionChange('address'); }} className={selectedOption === 'address' ? 'active' : ''}>
                            Address
                        </button>
                    </div>
                    {selectedOption === 'profile' && (
                <div className="profile-info">
                    <h1><strong>Profile Info</strong></h1>
                    <table>
                        <tbody>
                            <tr>
                                <td><label htmlFor="name">Name </label></td>
                                <td>
                                    <input
                                        type="text"
                                        id="name"
                                        value={profileInfo.Name}
                                        onChange={(e) => setProfileInfo({ ...profileInfo, Name: e.target.value })}
                                        placeholder="Enter Name"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td><label htmlFor="employeeid">EmployeeID </label></td>
                                <td>
                                    <input
                                        type="password"
                                        id="employeeid"
                                        value={profileInfo.EmployeeID}
                                        onChange={(e) => setProfileInfo({ ...profileInfo, EmployeeID: e.target.value })}
                                        placeholder="Enter EmployeeID"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td><label htmlFor="companyemail">CompanyEmail </label></td>
                                <td>
                                    <input
                                        type="text"
                                        id="companyemail"
                                        value={profileInfo.CompanyEmail}
                                        onChange={(e) => setProfileInfo({ ...profileInfo, CompanyEmail: e.target.value })}
                                        placeholder="Enter CompanyEmail"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td><label htmlFor="location">Location </label></td>
                                <td>
                                    <input
                                        type="text"
                                        id="location"
                                        value={profileInfo.Location}
                                        onChange={(e) => setProfileInfo({ ...profileInfo, Location: e.target.value })}
                                        placeholder="Enter Location"
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            )}
                    {selectedOption === 'personal' && (
                        <div className="personal">
                            <h1><strong>Personal</strong></h1>
                            <table>
                        <tbody>
                            <tr>
                            <td><label htmlFor="bloodGroup">Blood Group </label></td>
                            <td>
                    <input
                        type="text"
                        id="bloodGroup"
                        value={personalInfo.BloodGroup}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, BloodGroup: e.target.value })}
                        placeholder="Enter Blood Group"
                    />
                    </td>
                    </tr>
                    <tr>
                   
                    <td><label htmlFor="dateofbirth">DateofBirth </label></td>
                    <td>
                    <input
                        type="date"
                        id="dateofbirth"
                        value={personalInfo.DateofBirth}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, DateofBirth: e.target.value })}
                        placeholder="Enter DateofBirth"
                    />
                    </td>
                   
                    </tr>
                    <tr>
                   
                    <td><label htmlFor="physicallychallenged">PhysicallyChallenged </label></td>
                    <td>
                    <input
                        type="text"
                        id="physicallychallenged"
                        value={personalInfo.PhysicallyChallenged}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, PhysicallyChallenged: e.target.value })}
                        placeholder="Enter PhysicallyChallenged"
                    />
                    </td>
                    </tr>
                    <tr>
                    <td><label htmlFor="nationality">Nationality </label></td>
                    <td>
                    <input
                        type="text"
                        id="Nationality"
                        value={profileInfo.Nationality}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, Nationality: e.target.value })}
                        placeholder="Enter Nationality"
                    />
                    </td>
                    </tr>
                    </tbody>
                    </table>
                        </div>
 
                    )}
                    {selectedOption === 'address' && (
                        <div className="address">
                            <h1><strong>Address</strong></h1>
                            <label htmlFor="addressType">Select Address Type </label>
                    <select
                        id="addressType"
                        value={addressType}
                        onChange={(e) => setAddressType(e.target.value)}
                    >
                                <option value="Contact Address">Contact Address</option>
                                <option value="Permanent Address">Permanent Address</option>
                                <option value="Present Address">Present Address</option>
                                <option value="Emergency Address">Emergency Address</option>
                            </select>
                            <table>
                                <tbody>
                                    <tr>
                           <td><label htmlFor="address">Address:</label></td>
                           <td>
                    <input
                        type="text"
                        id="address"
                        value={addressInfo.Address}
                        onChange={(e) => setAddressInfo({ ...addressInfo, Address: e.target.value })}
                        placeholder="Enter Address"
                    />
                    </td>
                    </tr>
                    <tr>
                    <td><label htmlFor="name">Name </label></td>
                    <td>
                    <input
                        type="text"
                        id="name"
                        value={addressInfo.Name}
                        onChange={(e) => setAddressInfo({ ...addressInfo, Name: e.target.value })}
                        placeholder="Enter Name"
                    />
                    </td>
                    </tr>
                    <tr>
                    <td><label htmlFor="email">Email </label></td>
                    <td>
                    <input
                        type="text"
                        id="email"
                        value={addressInfo.Email}
                        onChange={(e) => setAddressInfo({ ...addressInfo, Email: e.target.value })}
                        placeholder="Enter Email"
                    />
                    </td>
                    </tr>
                    <tr>
                    <td><label htmlFor="mobile">Mobile </label></td>
                    <td>
                    <input
                        type="password"
                        id="mobile"
                        value={addressInfo.Email}
                        onChange={(e) => setAddressInfo({ ...addressInfo, Email: e.target.value })}
                        placeholder="Enter Email"
                    />
                    </td>
                    </tr>
                    </tbody>
                    </table>
                           
                        </div>
                    )}
                </div>
            </div>
        </div>
 
    );
}
export default Info;