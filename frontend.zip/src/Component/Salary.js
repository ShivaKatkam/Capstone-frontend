import React, { useState } from "react";
import SideBar from "./SideBar";
import HomeNavbar from "./HomeNavbar";

function Salary() {
    const [selectedOption, setSelectedOption] = useState('salary');

    const [salaryData, setSalaryData] = useState({
        basicSalary: '',
        bonuses: '',
        allowances: '',
    });

    const [deductionData, setDeductionData] = useState({
        tax: '',
        insurance: '',
    });

    const [attendanceData, setAttendanceData] = useState({
        empid: '',
        noofleaves: '',
        leavestaken: '',
        month: '',
        year: '',
    });

    const handleOptionChange = function (option) {
        setSelectedOption(option);
    };

    const handleSalaryInputChange = (field, value) => {
        setSalaryData({ ...salaryData, [field]: value });
    };

    const handleDeductionInputChange = (field, value) => {
        setDeductionData({ ...deductionData, [field]: value });
    };

    const handleAttendanceInputChange = (field, value) => {
        setAttendanceData({ ...attendanceData, [field]: value });
    };

    return (
        <div className="flex flex-col h-screen">
           <div> <HomeNavbar/></div>
            <div className='flex flex-1'>

                <SideBar />
                <div className='flex flex-1'>
                    <div className="salary">
                        <div className="header">
                            <h1>Salary Details</h1>
                        </div>

                        <div className="options">
                            <button onClick={() => handleOptionChange('salary')} className={selectedOption === 'salary' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                Salary
                            </button>
                            <button onClick={() => handleOptionChange('deduction')} className={selectedOption === 'deduction' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                Deduction
                            </button>
                            <button onClick={() => handleOptionChange('netpay')} className={selectedOption === 'netpay' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                Net Pay
                            </button>
                            <button onClick={() => handleOptionChange('attendance')} className={selectedOption === 'attendance' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                Attendance
                            </button>
                        </div>

                        {selectedOption === 'salary' && (
                            <div className="salary-details">
                                <h1><strong>Salary Details</strong></h1>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>Basic Salary </td>
                                            <td><input type="text" value={salaryData.basicSalary} onChange={(e) => handleSalaryInputChange('basicSalary', e.target.value)} placeholder="Enter Basic Salary" /></td>
                                        </tr>
                                        <tr>
                                            <td>Bonuses </td>
                                            <td><input type="text" value={salaryData.bonuses} onChange={(e) => handleSalaryInputChange('bonuses', e.target.value)} placeholder="Enter Bonuses" /></td>
                                        </tr>
                                        <tr>
                                            <td>Allowances </td>
                                            <td><input type="text" value={salaryData.allowances} onChange={(e) => handleSalaryInputChange('allowances', e.target.value)} placeholder="Enter Allowances" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        )}

                        {selectedOption === 'deduction' && (
                            <div className="deduction-details">
                                <h1><strong>Deduction Details</strong></h1>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>Tax </td>
                                            <td><input type="text" value={deductionData.tax} onChange={(e) => handleDeductionInputChange('tax', e.target.value)} placeholder="Enter Tax" /></td>
                                        </tr>
                                        <tr>
                                            <td>Insurance </td>
                                            <td><input type="text" value={deductionData.insurance} onChange={(e) => handleDeductionInputChange('insurance', e.target.value)} placeholder="Enter Insurance" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        )}

                        {selectedOption === 'netpay' && (
                            <div className="netpay-details">
                                <h1><strong>Net Pay</strong></h1>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>TotalEarnings </td>
                                            <td><input type="text" value={deductionData.tax} onChange={(e) => handleDeductionInputChange('tax', e.target.value)} placeholder="Enter Tax" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        )}

                        {selectedOption === 'attendance' && (
                            <div className="attendance-details">
                                <h1><strong>Attendance Details</strong></h1>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>Employee ID </td>
                                            <td><input type="text" value={attendanceData.empid} onChange={(e) => handleAttendanceInputChange('empid', e.target.value)} placeholder="Enter Employee ID" /></td>
                                        </tr>
                                        <tr>
                                            <td>No. of Leaves </td>
                                            <td><input type="text" value={attendanceData.noofleaves} onChange={(e) => handleAttendanceInputChange('noofleaves', e.target.value)} placeholder="Enter No. of Leaves" /></td>
                                        </tr>
                                        <tr>
                                            <td>Leaves Taken </td>
                                            <td><input type="text" value={attendanceData.leavestaken} onChange={(e) => handleAttendanceInputChange('leavestaken', e.target.value)} placeholder="Enter Leaves Taken" /></td>
                                        </tr>
                                        <tr>
                                            <td>Month </td>
                                            <td><input type="text" value={attendanceData.month} onChange={(e) => handleAttendanceInputChange('month', e.target.value)} placeholder="Enter Month" /></td>
                                        </tr>
                                        <tr>
                                            <td>Year </td>
                                            <td><input type="text" value={attendanceData.year} onChange={(e) => handleAttendanceInputChange('year', e.target.value)} placeholder="Enter Year" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Salary;