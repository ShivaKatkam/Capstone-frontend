import React from "react";
import HrSidebar from "./HrSidebar";
import './HrDocumentCenter.css';
import HrNavbar from "./HrNavbar";

function HrDocumentCenter(){
    const payslipData = {
        employeeName: 'John Doe',
        salary: '$5000',
        bonuses: '$1000',
      };
return(
    <div className="flex flex-col h-screen" >

    <div><HrNavbar /></div>
    <div className='flex flex-1'>

        <HrSidebar />
        <div className='flex flex-1'>
        <div className="document-center">
      <div className="header">
        <h1>Document Center</h1>
      </div>

      <div className="payslip-section">
        <h2>Payslip</h2>
        <p>Employee: {payslipData.employeeName}</p>
        <p>Salary: {payslipData.salary}</p>
        <p>Bonuses: {payslipData.bonuses}</p>

        {/* Download link */}
        <a href="/Downloads/payslip.pdf" download className="download-link">
          Download Payslip
        </a>
      </div>
      <div className="policies-section">
        <h2>Company Policies</h2>
        <p>Here you can find information about our company policies.</p>

        {/* Link to navigate to ViewAll component */}
       
        <a href="https://www.infinite.com" target="_blank" rel="noopener noreferrer" className="view-all-link">
          View All
          </a>
        
      </div>

      {/* ... other JSX code ... */}
    </div>
    </div>
    </div>
    </div>
  );
}

export default HrDocumentCenter;