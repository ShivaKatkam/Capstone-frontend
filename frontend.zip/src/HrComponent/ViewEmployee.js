import React, { useEffect, useState } from "react";
import axios from "axios";
import HrHomeNavbar from "./HrHomeNavbar";

function ViewEmployee() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:8080/api/allemployees")
      .then((result) => {
        console.log(result.data);
        setPosts(result.data);
      })
      .catch((error) => console.log(error));
  }, []);


  return (
    <div>
      <HrHomeNavbar />
      <div className="container">
        <div className="py-4">
          <table className="table border shadow" cellSpacing={1} cellPadding={20}>
            <thead>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Department</th>
              <th>Designation</th>
              <th>Last Login</th>
            </thead>
            <tbody>
              {
                posts.map(data =>
                  <tr key={data.emp_id}>
                    <td>{data.emp_id}</td>
                    <td>{data.emp_name}</td>
                    <td>{data.email}</td>
                    <td>{data.department}</td>
                    <td>{data.designation}</td>
                    <td>{data.last_login}</td>
                  </tr>
                )
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
export default ViewEmployee;