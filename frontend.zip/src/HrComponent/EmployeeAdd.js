import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import HrHomeNavbar from "../HrComponent/HrHomeNavbar";

function EmployeeAdd() {
  let navigate = useNavigate();

  const [user, setUser] = useState({
    emp_id: "",
    emp_name: "",
    email: "",
    department:"",
    designation:""
  });

  const { emp_id, emp_name, email,department,designation } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/api/newemployee", user);
    navigate("/viewemployee");
  };

  return (
    <div>
      <HrHomeNavbar />
      <div className="container">
        <div className="row">
          <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
            <h2 className="text-center m-4">Add Employee</h2>

            <form onSubmit={(e) => onSubmit(e)}>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Employee ID
                </label>
                <input
                  type={"number"}
                  className="form-control"
                  placeholder="Enter the Employee ID"
                  name="emp_id"
                  value={emp_id}
                  onChange={(e) => onInputChange(e)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="Employee Name" className="form-label">
                  Employee Name
                </label>
                <input
                  type={"text"}
                  className="form-control"
                  placeholder="Enter the Employee name"
                  name="emp_name"
                  value={emp_name}
                  onChange={(e) => onInputChange(e)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="Price" className="form-label">
                  Email
                </label>
                <input
                  type={"text"}
                  className="form-control"
                  placeholder="Enter the Email"
                  name="email"
                  value={email}
                  onChange={(e) => onInputChange(e)}
                />
              </div>
              <div>
                <label htmlFor="Department" className="form-label">
                  Department
                </label>
                <select
                  className="form-control"
                  placeholder="Select the Department"
                  name="department"
                  id={department}
                  onChange={(e) => onInputChange(e)}
                >
                  <option value={"hr"}>HR</option>
                  <option value={"developer"}>Developer</option>
                  <option value={"tester"}>Tester</option>
                  <option value={"architect"}>Architect</option>
                  <option value={"manager"}>Manager</option>
                  <option value={"engineer"}>Engineer</option>
                </select>
              </div>
              <div>
                <label htmlFor="Designation" className="form-label">
                  Designation
                </label>
                <select
                  className="form-control"
                  placeholder="Select the Designation"
                  name="designation"
                  id={designation}
                  onChange={(e) => onInputChange(e)}
                >
                  <option value={"intern"}>Intern</option>
                  <option value={"associate"}>Associate</option>
                  <option value={"senior"}>Senior</option>
                </select>
              </div>
              <button type="submit" className="btn btn-outline-primary">
                Submit
              </button>
              <Link className="btn btn-outline-danger mx-2" to="/hrhome">
                Cancel
              </Link>
            </form>
          </div>
        </div>
      </div>
    </div>

  );
}
export default EmployeeAdd;