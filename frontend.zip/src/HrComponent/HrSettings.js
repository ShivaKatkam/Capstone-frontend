import React, { useState } from "react";
import HrNavbar from "./HrNavbar";
import HrSideBar from "./HrSidebar";
import './HrSettings.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { faEdit, faCog } from '@fortawesome/free-solid-svg-icons';
function HrSettings() {
  const [profileInfo, setProfileInfo] = useState({
    name: '',
    dateOfBirth: '',
    Email: '',
    empId: '',
    department: '',
    designation: '',
    nickname: '',
    wishMeOn: '',
    timezone: '',
    biography: '',
    socialMedia: 'Infinite Computer Solutions רו',
  });
  function handleEdit(field) {
    const newValue = prompt(`Enter new value for ${field}:`);
    if (newValue !== null) {
      setProfileInfo(function (prevProfileInfo) {
        return {
          ...prevProfileInfo,
          [field]: newValue,
        };
      });
    }
  }
  function handleNameChange(event) {
    setProfileInfo(function (prevProfileInfo) {
      return {
        ...prevProfileInfo,
        name: event.target.value,
      };
    });
  }
  function handleChange(field, event) {
    setProfileInfo((prevProfileInfo) => ({
      ...prevProfileInfo,
      [field]: event.target.value,
    }));
  }
 
  return (
    <div className="flex flex-col h-screen" >
 
      <div><HrNavbar /></div>
      <div className='flex flex-1'>
 
        <HrSideBar />
        <div className="container">
          <div className="row">
            <div className="col-lg-4">
              <div className='flex flex-1'>
                <div className="setting-container">
                  <div className="profile-icon">
                    <FontAwesomeIcon icon={faUser} size="3x" />
                  </div>
                  <h1>Profile Information</h1>
                  <p>
                    Name:{' '}
                    <input
                      type="text" placeholder="name"
                      value={profileInfo.name}
                      onChange={(e) => handleChange('name', e)} />
                  </p>
                  <div>
                    <p>
                      Date of Birth:{' '}
                      <input
                        type="date"
                        placeholder="name"
                        value={profileInfo.dateOfBirth}
                        onChange={(e) => handleChange('dateOfBirth', e)}
                      />
                    </p>
                  </div>
 
                  <div>
                    <p>
                      Email:{' '}
                      <input
                        type="text"
                        placeholder="email"
                        value={profileInfo.Email}
                        onChange={(e) => handleChange('Email', e)}
                      />
                    </p>
                  </div>
                  <div>
                    <p>
                      Emp ID:{' '}
                      <input
                        type="text"
                        placeholder="emp_id"
                        value={profileInfo.empId}
                        onChange={(e) => handleChange('empId', e)}
                      />
                    </p>
                  </div>
                  <div>
                    <p>
                      Department:{' '}
                      <input
                        type="text"
                        placeholder="dept"
                        value={profileInfo.department}
                        onChange={(e) => handleChange('department', e)}
                      />
                    </p>
                  </div>
                  <div>
                    <p>
                      Designation:{' '}
                      <input
                        type="text"
                        placeholder="designation"
                        value={profileInfo.designation}
                        onChange={(e) => handleChange('designation', e)}
                      />
                    </p>
                  </div>
                </div>
              </div>
            </div>
 
            <div className="col-lg-4">
              <div className="setting-container" >
                <div className="my-profile-section">
                  <h2>My Profile</h2>
                  <div className="profile-section ">
                    <div className="block text-sm font-medium leading-6 text-gray-900">
 
 
 
                      Profile Nickname:{' '}<FontAwesomeIcon icon={faEdit} onClick={() => handleEdit('nickname')} />
                      <input
                        type="text"
                        value={profileInfo.nickname}
                        onChange={(e) => handleChange('nickname', e)}
                      />{' '}
 
 
 
 
                    </div>
                    <div>
 
                      Wish me on:{' '}<FontAwesomeIcon icon={faEdit} onClick={() => handleEdit('wishMeOn')} />
                      <input
                        type="text"
                        value={profileInfo.wishMeOn}
                        onChange={(e) => handleChange('wishMeOn', e)}
                      />{' '}
 
 
                    </div>
 
                    Timezone:{' '}<FontAwesomeIcon icon={faEdit} onClick={() => handleEdit('timezone')} />
                    <input
                      type="text"
                      value={profileInfo.timezone}
                      onChange={(e) => handleChange('timezone', e)}
                    />{' '}
 
 
 
                    Biography:{' '}<FontAwesomeIcon icon={faEdit} onClick={() => handleEdit('biography')} />
                    <input
                      type="text"
                      value={profileInfo.biography}
                      onChange={(e) => handleChange('biography', e)}
                    />{' '}
 
 
 
                    Social Media:{' '}<FontAwesomeIcon icon={faEdit} onClick={() => handleEdit('socialMedia')} />
                    <input
                      type="text"
                      value={profileInfo.socialMedia}
                      onChange={(e) => handleChange('socialMedia', e)}
                    />{' '}
 
 
                  </div>
                </div></div>
            </div>
            <div className="col-lg-3">
 
              <div className="change-password">
                <p>
                  <FontAwesomeIcon icon={faCog} />
                  <span className="change-password-link">Change Password</span>
                </p>
              </div>
 
            </div>
 
          </div>
        </div>
      </div>
    </div>
  );
}
 
export default HrSettings;
 