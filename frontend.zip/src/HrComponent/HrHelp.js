import React, { useState } from "react";
import "./HrHelp.css";
import HrNavbar from "./HrNavbar";
import HrSidebar from "./HrSidebar";

function HrHelp() {
  const [selectedOption, setSelectedOption] = useState('Personal');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    description: '',
    category: '',
  });
  const [submittedRequests, setSubmittedRequests] = useState([]);

  function handleOptionChange(option) {
    setSelectedOption(option);
    // Show the form when 'NewRequest' is selected
    setShowForm(option === 'newrequest');
  }

  function handleInputChange(event) {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  }

  function handleSubmit(event) {
    // Prevent the default form submission behavior
    event.preventDefault();
    // Create a new request object from the form data
    const newRequest = { ...formData, id: Date.now() }; // Adding a unique ID
    // Update the list of submitted requests
    setSubmittedRequests([...submittedRequests, newRequest]);
    // Optionally, you can reset the form data after submission
    setFormData({
      description: '',
      category: '',
    });
  }

  return (
    <div className="flex flex-col h-screen">
      <div><HrNavbar/></div>
      <div className='flex flex-1'>
        <HrSidebar />
        <center>
          <div className="flex-1 p-8">
            <h1>Help Desk</h1>
            <div className="options">
              <button onClick={() => handleOptionChange('newrequest')} className={`button-small ${selectedOption === 'newrequest' ? 'active' : ''}`}>
                NewRequest
              </button>
            </div>

            {/* Display the form when 'NewRequest' is selected */}
            {showForm && (
              <div>
                <form onSubmit={handleSubmit}>
                  <table width="60%">
                    <tbody>
                      <tr>
                        <td><label htmlFor="description">Description </label></td>
                        <td>
                          <textarea
                            name="description"
                            value={formData.description}
                            onChange={handleInputChange}
                            style={{ width: '300%', height: '100px' }}
                          />
                        </td>
                      </tr>
                      <tr>
                        <td><label htmlFor="category">Category </label></td>
                        <td>
                          <select
                            name="category"
                            value={formData.category}
                            onChange={handleInputChange}
                            style={{ width: '300%' }}
                          >
                            <option value="Employee Info">Employee Info</option>
                            <option value="loan">Loan</option>
                            <option value="income tax">Income Tax</option>
                            <option value="others">Others</option>
                          </select>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <button
                    type="submit"
                    className="w-32 px-4 py-2 mt-6 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-500 rounded-md hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-50"
                  >
                    Submit
                  </button>
                </form>

                {/* Display submitted requests in a table */}


                <table width="60%" cellPadding={50} cellSpacing={10} >

                  <thead>
                    <tr>
                      
                      <th>Description</th>
                      <th>Category</th>
                    </tr>
                  </thead>
                  <tbody>
                    {submittedRequests.map(request => (
                      <tr key={request.description}>
                        
                        <td>{request.description}</td>
                        <td>{request.category}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </center>
      </div>
    </div>
  );
}

export default HrHelp;